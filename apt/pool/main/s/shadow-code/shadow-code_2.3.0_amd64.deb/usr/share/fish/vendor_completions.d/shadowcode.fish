# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_shadowcode_global_optspecs
    string join \n p/workspace= profile= json h/help V/version
end

function __fish_shadowcode_needs_command
    # Figure out if the current invocation already has a command.
    set -l cmd (commandline -opc)
    set -e cmd[1]
    argparse -s (__fish_shadowcode_global_optspecs) -- $cmd 2>/dev/null
    or return
    if set -q argv[1]
        # Also print the command, so this can be used to figure out what it is.
        echo $argv[1]
        return 1
    end
    return 0
end

function __fish_shadowcode_using_subcommand
    set -l cmd (__fish_shadowcode_needs_command)
    test -z "$cmd"
    and return 1
    contains -- $cmd[1] $argv
end

complete -c shadowcode -n "__fish_shadowcode_needs_command" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_needs_command" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_needs_command" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "ui" -d 'Open the desktop window (also the default)'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "tui" -d 'Open the native full-screen terminal workspace'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "run" -d 'Run a task, stream its progress, and return its actual exit status'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "exec" -d 'Run an exact user-supplied terminal command'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "command" -d 'Run a slash command, or list available commands with no argument'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "skill" -d 'List or run a project skill'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "worktree" -d 'List managed worktrees, or create an isolated branch at a local commit'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "status" -d 'Show the selected project and active work'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "sqlite" -d 'List tables or run one read-only query against an existing project database'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "health" -d 'Inspect native runtime and configured provider health'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "doctor" -d 'Inspect native installation, profile, project and optional model response'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "install-snapshot" -d 'Installer use: copy the profile database to a new file with SQLite\'s `VACUUM INTO` (never a raw copy of a live WAL database), without opening or migrating it. Prints the copied database format, or `absent` when the profile has no database yet'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "backup" -d 'Back up your conversations, jobs, goals and settings to a folder'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "restore" -d 'Check a backup and restore it (the current data is backed up first)'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "reset" -d 'Start over: move settings and history aside (nothing is deleted)'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "memory" -d 'Read or append project notes, or select an exact task\'s notes'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "understand" -d 'Inspect the project without running code or a model'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "why" -d 'Show recorded commit history and pending changes for a path'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "models" -d 'List, register, or select models'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "config" -d 'Read settings or set a validated dotted key to a JSON value or text'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "trust" -d 'Explicitly trust the current project for task execution'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "hooks" -d 'List lifecycle commands, or explicitly activate an unchanged project hook'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "mcp" -d 'List inert MCP definitions, register one, or review a project activation'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "rules" -d 'Your rulebook: profile and project rules, skills and commands'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "plugin" -d 'Review, install or remove declarative plugins in the selected project'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "sessions" -d 'List/search saved conversations, or rename/delete a unique ID prefix'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "export" -d 'Export a complete saved conversation to stdout or an atomic file'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "jobs" -d 'List jobs, inspect one, watch its events, or cancel it'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "approvals" -d 'List pending approvals or decide one explicitly'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "spending" -d 'Show spending limits for paid API models, today\'s total and tasks waiting at a limit; answer one with --job and --decision'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "goal" -d 'Create a durable goal and optionally run its milestones'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "goals" -d 'List goals, resume one, or pause it'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "background" -d 'Manage servers and watchers owned by the active desktop or headless server'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "checkpoints" -d 'List or restore this conversation\'s latest file-tool checkpoint'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "serve" -d 'Run the shared engine without a window until Ctrl-C or SIGTERM'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "acp" -d 'Serve the Agent Client Protocol on stdio for Zed, JetBrains and other ACP editors'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "remote" -d 'Remote access: show status, create a pairing link, or unpair devices'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "completions" -d 'Print a shell completion script (for example `shadowcode completions bash > ~/.local/share/bash-completion/completions/shadowcode`)'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "manpage" -d 'Print the manual page in roff format (packaging uses this)'
complete -c shadowcode -n "__fish_shadowcode_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand ui" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand ui" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand ui" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand ui" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand ui" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand tui" -s s -l session -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand tui" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand tui" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand tui" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand tui" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand tui" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand run" -s s -l session -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand run" -l model -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand run" -l purpose -l agent -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand run" -l approval -d 'How to handle a tool approval without an interactive terminal' -r -f -a "cancel\t'Stop the task and exit with code 2'
wait\t'Leave the request for the desktop or `shadowcode approvals`'
approve\t'Approve each request this task raises. For disposable machines such as CI runners only; denied actions and project permissions still apply'"
complete -c shadowcode -n "__fish_shadowcode_using_subcommand run" -l max-cost -d 'Spending limit for this task on paid API models, in US dollars (instead of `spending.task_usd`). Subscriptions and local models are never limited' -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand run" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand run" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand run" -l queue -d 'Queue behind a task already running in this project'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand run" -l interactive -d 'Ask for tool approval in this terminal (requires a TTY)'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand run" -l events -d 'Emit newline-delimited event JSON followed by the final result'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand run" -l detach -d 'Leave the task running in a persistent desktop/server engine'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand run" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand run" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand run" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand exec" -l timeout -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand exec" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand exec" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand exec" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand exec" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand exec" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand command" -s s -l session -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand command" -l model -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand command" -l purpose -l agent -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand command" -l approval -d 'How to handle a tool approval without an interactive terminal' -r -f -a "cancel\t'Stop the task and exit with code 2'
wait\t'Leave the request for the desktop or `shadowcode approvals`'
approve\t'Approve each request this task raises. For disposable machines such as CI runners only; denied actions and project permissions still apply'"
complete -c shadowcode -n "__fish_shadowcode_using_subcommand command" -l max-cost -d 'Spending limit for this task on paid API models, in US dollars (instead of `spending.task_usd`). Subscriptions and local models are never limited' -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand command" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand command" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand command" -l queue -d 'Queue behind a task already running in this project'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand command" -l interactive -d 'Ask for tool approval in this terminal (requires a TTY)'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand command" -l events -d 'Emit newline-delimited event JSON followed by the final result'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand command" -l detach -d 'Leave the task running in a persistent desktop/server engine'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand command" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand command" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand command" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand skill" -s s -l session -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand skill" -l model -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand skill" -l purpose -l agent -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand skill" -l approval -d 'How to handle a tool approval without an interactive terminal' -r -f -a "cancel\t'Stop the task and exit with code 2'
wait\t'Leave the request for the desktop or `shadowcode approvals`'
approve\t'Approve each request this task raises. For disposable machines such as CI runners only; denied actions and project permissions still apply'"
complete -c shadowcode -n "__fish_shadowcode_using_subcommand skill" -l max-cost -d 'Spending limit for this task on paid API models, in US dollars (instead of `spending.task_usd`). Subscriptions and local models are never limited' -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand skill" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand skill" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand skill" -l list
complete -c shadowcode -n "__fish_shadowcode_using_subcommand skill" -l queue -d 'Queue behind a task already running in this project'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand skill" -l interactive -d 'Ask for tool approval in this terminal (requires a TTY)'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand skill" -l events -d 'Emit newline-delimited event JSON followed by the final result'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand skill" -l detach -d 'Leave the task running in a persistent desktop/server engine'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand skill" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand skill" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand skill" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand worktree" -l inspect -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand worktree" -l remove -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand worktree" -l hash -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand worktree" -l recovery -d 'Review retained commits for a missing managed checkout' -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand worktree" -l restore -d 'Restore a reviewed commit to a separate checkout, retaining original metadata' -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand worktree" -l recovery-hash -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand worktree" -l review-return -d 'Review committed changes before returning them to the source project' -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand worktree" -l return-changes -d 'Prepare a reviewed merge in the source checkout without committing' -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand worktree" -l return-hash -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand worktree" -l copy-hash -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand worktree" -l review-repair -d 'Review missing Git connection files at the original managed location' -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand worktree" -l repair -d 'Restore reviewed missing connections while preserving files and staging' -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand worktree" -l repair-hash -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand worktree" -l reference -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand worktree" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand worktree" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand worktree" -l create
complete -c shadowcode -n "__fish_shadowcode_using_subcommand worktree" -l review-changes -d 'Review source edits, staging split and untracked files for an isolated copy'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand worktree" -l copy-changes -d 'Copy reviewed source edits into a new worktree without altering the source'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand worktree" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand worktree" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand worktree" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand status" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand status" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand status" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand status" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand status" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand sqlite" -l params -d 'JSON array of values bound to positional SQL placeholders' -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand sqlite" -l limit -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand sqlite" -l timeout-ms -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand sqlite" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand sqlite" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand sqlite" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand sqlite" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand sqlite" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand health" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand health" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand health" -l test-model
complete -c shadowcode -n "__fish_shadowcode_using_subcommand health" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand health" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand health" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand doctor" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand doctor" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand doctor" -l test-model
complete -c shadowcode -n "__fish_shadowcode_using_subcommand doctor" -l repair -d 'First back up the database, check its integrity, rebuild its indexes and clear regenerable caches (Settings › Your data › Repair)'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand doctor" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand doctor" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand doctor" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand install-snapshot" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand install-snapshot" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand install-snapshot" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand install-snapshot" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand install-snapshot" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand backup" -s o -l output -d 'Folder to put the backup in (default: the profile\'s backups folder)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand backup" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand backup" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand backup" -l include-secrets -d 'Also copy API keys (secrets.env and keys kept in the desktop keyring) and remote-access pairing. Anyone with the backup can then use those keys'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand backup" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand backup" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand backup" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand restore" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand restore" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand restore" -l include-secrets -d 'Also restore API keys when the backup has them'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand restore" -l include-remote -d 'Also restore remote access, paired devices and phone notification settings when the backup has them. Devices you removed since then come back too, so remote access comes back off, and the restored devices cannot connect and notifications are not sent until you turn it on in Settings › Remote access'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand restore" -l yes -d 'Restore; without it only the check runs'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand restore" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand restore" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand restore" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand reset" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand reset" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand reset" -l yes -d 'Reset; without it only what would move is shown'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand reset" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand reset" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand reset" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand memory" -l task -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand memory" -l expected-hash -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand memory" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand memory" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand memory" -l replace -d 'Replace notes (an empty string clears them) after reading their hash'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand memory" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand memory" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand memory" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand understand" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand understand" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand understand" -l save
complete -c shadowcode -n "__fish_shadowcode_using_subcommand understand" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand understand" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand understand" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand why" -l count -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand why" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand why" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand why" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand why" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand why" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand models" -s u -l use -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand models" -l provider -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand models" -l endpoint -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand models" -l api-key-env -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand models" -l context-limit -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand models" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand models" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand models" -l no-detect
complete -c shadowcode -n "__fish_shadowcode_using_subcommand models" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand models" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand models" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand config" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand config" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand config" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand config" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand config" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand trust" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand trust" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand trust" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand trust" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand trust" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand hooks" -l enable -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand hooks" -l disable -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand hooks" -l hash -d 'Content hash shown by `hooks --json`; required when enabling' -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand hooks" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand hooks" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand hooks" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand hooks" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand hooks" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and not __fish_seen_subcommand_from serve register add enable disable remove help" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and not __fish_seen_subcommand_from serve register add enable disable remove help" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and not __fish_seen_subcommand_from serve register add enable disable remove help" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and not __fish_seen_subcommand_from serve register add enable disable remove help" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and not __fish_seen_subcommand_from serve register add enable disable remove help" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and not __fish_seen_subcommand_from serve register add enable disable remove help" -f -a "serve" -d 'Expose this project over stdio or authenticated loopback HTTP, without a window'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and not __fish_seen_subcommand_from serve register add enable disable remove help" -f -a "register" -d 'Print MCP client configuration without editing another application\'s settings'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and not __fish_seen_subcommand_from serve register add enable disable remove help" -f -a "add" -d 'Register a JSON/YAML definition; does not launch or enable it'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and not __fish_seen_subcommand_from serve register add enable disable remove help" -f -a "enable" -d 'Allow this exact server definition to start for new Build tasks here'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and not __fish_seen_subcommand_from serve register add enable disable remove help" -f -a "disable" -d 'Revoke this project\'s activation for future tasks'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and not __fish_seen_subcommand_from serve register add enable disable remove help" -f -a "remove" -d 'Remove a global registration and its project activations'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and not __fish_seen_subcommand_from serve register add enable disable remove help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from serve" -l http -d 'Bind a loopback IP:port for Streamable HTTP instead of stdin/stdout' -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from serve" -l token-env -d 'Environment/profile-secret name containing a random bearer token (32–512 characters)' -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from serve" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from serve" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from serve" -l allow-write -d 'Delegate changes within the configured project permissions'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from serve" -l allow-approvals -d 'Delegate approval decisions for this MCP owner\'s tasks'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from serve" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from serve" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from serve" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from register" -l client -d 'Output format: generic JSON, Claude Code, Cursor, or Codex TOML' -r -f -a "generic\t''
claude\t''
cursor\t''
codex\t''"
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from register" -l url -d 'An already-running local HTTP gateway\'s /mcp URL (otherwise use stdio)' -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from register" -l token-env -d 'Credential variable name for the calling application; never reads its value' -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from register" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from register" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from register" -l allow-write
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from register" -l allow-approvals
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from register" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from register" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from register" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from add" -l hash -d 'Current definition hash when replacing an existing registration' -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from add" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from add" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from add" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from add" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from add" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from enable" -l hash -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from enable" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from enable" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from enable" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from enable" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from enable" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from disable" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from disable" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from disable" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from disable" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from disable" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from remove" -l hash -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from remove" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from remove" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from remove" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from remove" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from remove" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from help" -f -a "serve" -d 'Expose this project over stdio or authenticated loopback HTTP, without a window'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from help" -f -a "register" -d 'Print MCP client configuration without editing another application\'s settings'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from help" -f -a "add" -d 'Register a JSON/YAML definition; does not launch or enable it'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from help" -f -a "enable" -d 'Allow this exact server definition to start for new Build tasks here'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from help" -f -a "disable" -d 'Revoke this project\'s activation for future tasks'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from help" -f -a "remove" -d 'Remove a global registration and its project activations'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand mcp; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand rules; and not __fish_seen_subcommand_from check preview help" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand rules; and not __fish_seen_subcommand_from check preview help" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand rules; and not __fish_seen_subcommand_from check preview help" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand rules; and not __fish_seen_subcommand_from check preview help" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand rules; and not __fish_seen_subcommand_from check preview help" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand rules; and not __fish_seen_subcommand_from check preview help" -f -a "check" -d 'Check rules, skills, commands and agent files for problems. Reports only; nothing is changed. Exits 1 when there are errors'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand rules; and not __fish_seen_subcommand_from check preview help" -f -a "preview" -d 'Show what each agent reads from your rulebook for this project'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand rules; and not __fish_seen_subcommand_from check preview help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand rules; and __fish_seen_subcommand_from check" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand rules; and __fish_seen_subcommand_from check" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand rules; and __fish_seen_subcommand_from check" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand rules; and __fish_seen_subcommand_from check" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand rules; and __fish_seen_subcommand_from check" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand rules; and __fish_seen_subcommand_from preview" -l agent -d 'Only this agent: shadowcode, claude, codex, cursor, grok, antigravity' -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand rules; and __fish_seen_subcommand_from preview" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand rules; and __fish_seen_subcommand_from preview" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand rules; and __fish_seen_subcommand_from preview" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand rules; and __fish_seen_subcommand_from preview" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand rules; and __fish_seen_subcommand_from preview" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand rules; and __fish_seen_subcommand_from help" -f -a "check" -d 'Check rules, skills, commands and agent files for problems. Reports only; nothing is changed. Exits 1 when there are errors'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand rules; and __fish_seen_subcommand_from help" -f -a "preview" -d 'Show what each agent reads from your rulebook for this project'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand rules; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and not __fish_seen_subcommand_from inspect install remove help" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and not __fish_seen_subcommand_from inspect install remove help" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and not __fish_seen_subcommand_from inspect install remove help" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and not __fish_seen_subcommand_from inspect install remove help" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and not __fish_seen_subcommand_from inspect install remove help" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and not __fish_seen_subcommand_from inspect install remove help" -f -a "inspect" -d 'Show all generated files before installation'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and not __fish_seen_subcommand_from inspect install remove help" -f -a "install" -d 'Install a bundle whose hash was returned by inspect'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and not __fish_seen_subcommand_from inspect install remove help" -f -a "remove" -d 'Remove unchanged owned files and preserve local edits'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and not __fish_seen_subcommand_from inspect install remove help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and __fish_seen_subcommand_from inspect" -l file -d 'Read a local JSON bundle; no network download or code execution' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and __fish_seen_subcommand_from inspect" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and __fish_seen_subcommand_from inspect" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and __fish_seen_subcommand_from inspect" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and __fish_seen_subcommand_from inspect" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and __fish_seen_subcommand_from inspect" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and __fish_seen_subcommand_from install" -l file -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and __fish_seen_subcommand_from install" -l hash -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and __fish_seen_subcommand_from install" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and __fish_seen_subcommand_from install" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and __fish_seen_subcommand_from install" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and __fish_seen_subcommand_from install" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and __fish_seen_subcommand_from install" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and __fish_seen_subcommand_from remove" -l hash -d 'Current installation hash from the plugin catalog' -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and __fish_seen_subcommand_from remove" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and __fish_seen_subcommand_from remove" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and __fish_seen_subcommand_from remove" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and __fish_seen_subcommand_from remove" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and __fish_seen_subcommand_from remove" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and __fish_seen_subcommand_from help" -f -a "inspect" -d 'Show all generated files before installation'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and __fish_seen_subcommand_from help" -f -a "install" -d 'Install a bundle whose hash was returned by inspect'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and __fish_seen_subcommand_from help" -f -a "remove" -d 'Remove unchanged owned files and preserve local edits'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand plugin; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand sessions" -l rename -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand sessions" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand sessions" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand sessions" -l delete
complete -c shadowcode -n "__fish_shadowcode_using_subcommand sessions" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand sessions" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand sessions" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand export" -s s -l session -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand export" -l format -r -f -a "md\t''
json\t''"
complete -c shadowcode -n "__fish_shadowcode_using_subcommand export" -s o -l output -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand export" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand export" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand export" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand export" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand export" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand jobs" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand jobs" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand jobs" -l watch
complete -c shadowcode -n "__fish_shadowcode_using_subcommand jobs" -l cancel
complete -c shadowcode -n "__fish_shadowcode_using_subcommand jobs" -l interactive
complete -c shadowcode -n "__fish_shadowcode_using_subcommand jobs" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand jobs" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand jobs" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand approvals" -s s -l session -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand approvals" -l id -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand approvals" -l decision -r -f -a "approve\t''
deny\t''"
complete -c shadowcode -n "__fish_shadowcode_using_subcommand approvals" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand approvals" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand approvals" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand approvals" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand approvals" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand spending" -l job -d 'The waiting task\'s job ID' -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand spending" -l decision -r -f -a "continue\t''
stop\t''"
complete -c shadowcode -n "__fish_shadowcode_using_subcommand spending" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand spending" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand spending" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand spending" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand spending" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand goal" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand goal" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand goal" -l run
complete -c shadowcode -n "__fish_shadowcode_using_subcommand goal" -l detach
complete -c shadowcode -n "__fish_shadowcode_using_subcommand goal" -l interactive
complete -c shadowcode -n "__fish_shadowcode_using_subcommand goal" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand goal" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand goal" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand goals" -l resume -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand goals" -l pause -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand goals" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand goals" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand goals" -l interactive
complete -c shadowcode -n "__fish_shadowcode_using_subcommand goals" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand goals" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand goals" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and not __fish_seen_subcommand_from list start stop logs help" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and not __fish_seen_subcommand_from list start stop logs help" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and not __fish_seen_subcommand_from list start stop logs help" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and not __fish_seen_subcommand_from list start stop logs help" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and not __fish_seen_subcommand_from list start stop logs help" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and not __fish_seen_subcommand_from list start stop logs help" -f -a "list"
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and not __fish_seen_subcommand_from list start stop logs help" -f -a "start"
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and not __fish_seen_subcommand_from list start stop logs help" -f -a "stop"
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and not __fish_seen_subcommand_from list start stop logs help" -f -a "logs"
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and not __fish_seen_subcommand_from list start stop logs help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from list" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from list" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from list" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from list" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from start" -l name -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from start" -l command -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from start" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from start" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from start" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from start" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from start" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from stop" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from stop" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from stop" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from stop" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from stop" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from logs" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from logs" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from logs" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from logs" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from logs" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from help" -f -a "list"
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from help" -f -a "start"
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from help" -f -a "stop"
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from help" -f -a "logs"
complete -c shadowcode -n "__fish_shadowcode_using_subcommand background; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand checkpoints" -s s -l session -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand checkpoints" -l restore -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand checkpoints" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand checkpoints" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand checkpoints" -l undo
complete -c shadowcode -n "__fish_shadowcode_using_subcommand checkpoints" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand checkpoints" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand checkpoints" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand serve" -l remote-address -d 'Listen on this IP:port for this run instead of the saved remote access address (127.0.0.1:7390 unless changed in Settings)' -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand serve" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand serve" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand serve" -l remote -d 'Also serve the web interface and API for phones and other computers (paired devices only; see docs/REMOTE.md)'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand serve" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand serve" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand serve" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand acp" -l print-config -d 'Print editor configuration for this executable instead of serving' -r -f -a "zed\t'Zed `settings.json` → `agent_servers`'
jetbrains\t'JetBrains AI Assistant `~/.jetbrains/acp.json`'
generic\t'Command and arguments for any other ACP client'"
complete -c shadowcode -n "__fish_shadowcode_using_subcommand acp" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand acp" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand acp" -l trust -d 'Trust a project the first time an editor opens a session in it'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand acp" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand acp" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand acp" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and not __fish_seen_subcommand_from status pair revoke help" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and not __fish_seen_subcommand_from status pair revoke help" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and not __fish_seen_subcommand_from status pair revoke help" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and not __fish_seen_subcommand_from status pair revoke help" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and not __fish_seen_subcommand_from status pair revoke help" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and not __fish_seen_subcommand_from status pair revoke help" -f -a "status" -d 'Show whether remote access runs, where, and the paired devices'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and not __fish_seen_subcommand_from status pair revoke help" -f -a "pair" -d 'Print a one-time pairing link and QR code (valid 10 minutes)'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and not __fish_seen_subcommand_from status pair revoke help" -f -a "revoke" -d 'Unpair one device (by ID prefix), or every device with --all'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and not __fish_seen_subcommand_from status pair revoke help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and __fish_seen_subcommand_from status" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and __fish_seen_subcommand_from status" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and __fish_seen_subcommand_from status" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and __fish_seen_subcommand_from status" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and __fish_seen_subcommand_from status" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and __fish_seen_subcommand_from pair" -l host -d 'Which of this computer\'s addresses the link uses' -r
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and __fish_seen_subcommand_from pair" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and __fish_seen_subcommand_from pair" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and __fish_seen_subcommand_from pair" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and __fish_seen_subcommand_from pair" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and __fish_seen_subcommand_from pair" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and __fish_seen_subcommand_from revoke" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and __fish_seen_subcommand_from revoke" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and __fish_seen_subcommand_from revoke" -l all
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and __fish_seen_subcommand_from revoke" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and __fish_seen_subcommand_from revoke" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and __fish_seen_subcommand_from revoke" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and __fish_seen_subcommand_from help" -f -a "status" -d 'Show whether remote access runs, where, and the paired devices'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and __fish_seen_subcommand_from help" -f -a "pair" -d 'Print a one-time pairing link and QR code (valid 10 minutes)'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and __fish_seen_subcommand_from help" -f -a "revoke" -d 'Unpair one device (by ID prefix), or every device with --all'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand remote; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand completions" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand completions" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand completions" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand completions" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand completions" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand manpage" -s p -l workspace -l project -d 'Project folder (defaults to the current directory for CLI commands)' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand manpage" -l profile -d 'Isolated settings and history directory' -r -F
complete -c shadowcode -n "__fish_shadowcode_using_subcommand manpage" -l json -d 'Print one structured JSON result on stdout'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand manpage" -s h -l help -d 'Print help'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand manpage" -s V -l version -d 'Print version'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "ui" -d 'Open the desktop window (also the default)'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "tui" -d 'Open the native full-screen terminal workspace'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "run" -d 'Run a task, stream its progress, and return its actual exit status'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "exec" -d 'Run an exact user-supplied terminal command'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "command" -d 'Run a slash command, or list available commands with no argument'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "skill" -d 'List or run a project skill'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "worktree" -d 'List managed worktrees, or create an isolated branch at a local commit'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "status" -d 'Show the selected project and active work'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "sqlite" -d 'List tables or run one read-only query against an existing project database'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "health" -d 'Inspect native runtime and configured provider health'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "doctor" -d 'Inspect native installation, profile, project and optional model response'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "install-snapshot" -d 'Installer use: copy the profile database to a new file with SQLite\'s `VACUUM INTO` (never a raw copy of a live WAL database), without opening or migrating it. Prints the copied database format, or `absent` when the profile has no database yet'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "backup" -d 'Back up your conversations, jobs, goals and settings to a folder'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "restore" -d 'Check a backup and restore it (the current data is backed up first)'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "reset" -d 'Start over: move settings and history aside (nothing is deleted)'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "memory" -d 'Read or append project notes, or select an exact task\'s notes'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "understand" -d 'Inspect the project without running code or a model'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "why" -d 'Show recorded commit history and pending changes for a path'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "models" -d 'List, register, or select models'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "config" -d 'Read settings or set a validated dotted key to a JSON value or text'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "trust" -d 'Explicitly trust the current project for task execution'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "hooks" -d 'List lifecycle commands, or explicitly activate an unchanged project hook'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "mcp" -d 'List inert MCP definitions, register one, or review a project activation'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "rules" -d 'Your rulebook: profile and project rules, skills and commands'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "plugin" -d 'Review, install or remove declarative plugins in the selected project'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "sessions" -d 'List/search saved conversations, or rename/delete a unique ID prefix'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "export" -d 'Export a complete saved conversation to stdout or an atomic file'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "jobs" -d 'List jobs, inspect one, watch its events, or cancel it'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "approvals" -d 'List pending approvals or decide one explicitly'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "spending" -d 'Show spending limits for paid API models, today\'s total and tasks waiting at a limit; answer one with --job and --decision'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "goal" -d 'Create a durable goal and optionally run its milestones'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "goals" -d 'List goals, resume one, or pause it'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "background" -d 'Manage servers and watchers owned by the active desktop or headless server'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "checkpoints" -d 'List or restore this conversation\'s latest file-tool checkpoint'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "serve" -d 'Run the shared engine without a window until Ctrl-C or SIGTERM'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "acp" -d 'Serve the Agent Client Protocol on stdio for Zed, JetBrains and other ACP editors'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "remote" -d 'Remote access: show status, create a pairing link, or unpair devices'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "completions" -d 'Print a shell completion script (for example `shadowcode completions bash > ~/.local/share/bash-completion/completions/shadowcode`)'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "manpage" -d 'Print the manual page in roff format (packaging uses this)'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and not __fish_seen_subcommand_from ui tui run exec command skill worktree status sqlite health doctor install-snapshot backup restore reset memory understand why models config trust hooks mcp rules plugin sessions export jobs approvals spending goal goals background checkpoints serve acp remote completions manpage help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and __fish_seen_subcommand_from mcp" -f -a "serve" -d 'Expose this project over stdio or authenticated loopback HTTP, without a window'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and __fish_seen_subcommand_from mcp" -f -a "register" -d 'Print MCP client configuration without editing another application\'s settings'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and __fish_seen_subcommand_from mcp" -f -a "add" -d 'Register a JSON/YAML definition; does not launch or enable it'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and __fish_seen_subcommand_from mcp" -f -a "enable" -d 'Allow this exact server definition to start for new Build tasks here'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and __fish_seen_subcommand_from mcp" -f -a "disable" -d 'Revoke this project\'s activation for future tasks'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and __fish_seen_subcommand_from mcp" -f -a "remove" -d 'Remove a global registration and its project activations'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and __fish_seen_subcommand_from rules" -f -a "check" -d 'Check rules, skills, commands and agent files for problems. Reports only; nothing is changed. Exits 1 when there are errors'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and __fish_seen_subcommand_from rules" -f -a "preview" -d 'Show what each agent reads from your rulebook for this project'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and __fish_seen_subcommand_from plugin" -f -a "inspect" -d 'Show all generated files before installation'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and __fish_seen_subcommand_from plugin" -f -a "install" -d 'Install a bundle whose hash was returned by inspect'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and __fish_seen_subcommand_from plugin" -f -a "remove" -d 'Remove unchanged owned files and preserve local edits'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and __fish_seen_subcommand_from background" -f -a "list"
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and __fish_seen_subcommand_from background" -f -a "start"
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and __fish_seen_subcommand_from background" -f -a "stop"
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and __fish_seen_subcommand_from background" -f -a "logs"
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and __fish_seen_subcommand_from remote" -f -a "status" -d 'Show whether remote access runs, where, and the paired devices'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and __fish_seen_subcommand_from remote" -f -a "pair" -d 'Print a one-time pairing link and QR code (valid 10 minutes)'
complete -c shadowcode -n "__fish_shadowcode_using_subcommand help; and __fish_seen_subcommand_from remote" -f -a "revoke" -d 'Unpair one device (by ID prefix), or every device with --all'
