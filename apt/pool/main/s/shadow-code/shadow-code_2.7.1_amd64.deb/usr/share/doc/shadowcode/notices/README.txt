ShadowCode dependency notices

application.json lists application dependency versions, source locations, and notice hashes.
The original license and copyright texts are retained in the referenced files.
AppImage system libraries and helpers have a separate system.json inventory.
The application uses dynamic system libraries in Debian packages.
The bundled llama.cpp runtime carries its own NOTICES directory.
Corresponding-source release artifacts are tracked separately from this notice inventory.
